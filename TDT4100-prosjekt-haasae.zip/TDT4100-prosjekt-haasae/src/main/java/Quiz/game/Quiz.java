package Quiz.game;

import java.util.List;

public interface Quiz {
    List<Question> getQuizQuestions();

}